# Research blog release checklist

## Source and editorial control

- [ ] The latest author-edited draft is the working text.
- [ ] The manuscript, figures, and supplied terminology support the claims.
- [ ] Unresolved numerical or interpretive conflicts are flagged, not guessed away.
- [ ] The post addresses the author's principal messages without retelling every result.
- [ ] The study type, scope, dates, and evidence strength are accurate.
- [ ] All editorial comments and abandoned wording have been resolved.

## Language and structure

- [ ] The title is short, descriptive, and consistent with the author's choice.
- [ ] The opening is an inviting short summary, not a copied abstract.
- [ ] Subheadings express ideas rather than manuscript sections.
- [ ] Technical language is explained, paragraphs have clear jobs, and repetition is limited.
- [ ] Colons and parenthetical dashes have been avoided where possible.
- [ ] Any necessary parenthetical dash is short. Compound-word hyphens remain intact.
- [ ] Numbers, causal language, uncertainty, and limitations are preserved.
- [ ] Examples, quotations, and anecdotes are supported and not fabricated.
- [ ] The English length fits the relevant journal guidance or an explained exception.

## Figures and links

- [ ] Every figure supports a specific nearby point and remains legible.
- [ ] Captions explain how to read the figure and prevent likely misinterpretation.
- [ ] Numbering begins at 1 and follows blog order in both languages.
- [ ] Captions, callouts, alt text, and filenames agree.
- [ ] Cropped panels preserve the data, axes, units, and necessary context.
- [ ] Reuse permission and required credits are established.
- [ ] No generated image is presented as an original photograph or an empirical figure.
- [ ] Contextual hyperlinks replace repeated numbered references.
- [ ] URLs resolve to the intended sources, and the surrounding claims are supported.
- [ ] The paper's DOI is not confused with a dataset DOI.

## Bilingual consistency

- [ ] Chinese follows the corrected English and supplied Chinese terminology.
- [ ] The same main claims, examples, uncertainty, and limitations appear in both versions.
- [ ] Dates, numbers, species, units, hyperlinks, and figure order match.
- [ ] Chinese reads naturally rather than copying English sentence structure.
- [ ] Every substantive revision has been carried through both versions.

## Files and destination

- [ ] There is only one clearly identified final file per requested language and format.
- [ ] Markdown has no embedded CSS, style blocks, stray comments, or accidental code blocks.
- [ ] Relative image paths work after extracting the delivered ZIP.
- [ ] Word has true first-line indentation, compact spacing, embedded figures, and clickable links.
- [ ] Word and English Markdown have matching text and assets.
- [ ] Every rendered Word page has been visually inspected.
- [ ] Explicit download links are provided for the requested files.
- [ ] The editorial submission identifies any remaining publication metadata.
- [ ] Before public release, placeholders are replaced with confirmed details and the main article link.

Automated checks assist this review but do not establish scientific accuracy, translation quality, permissions, or editorial acceptance. Apply destination-specific requirements above reusable defaults.
