# {{Short descriptive title or question}}

  {{A short, inviting summary. State the broader question, the study's contribution, and its main implication without an Abstract label.}}

  {{Explain the wider problem in familiar terms.}}

  {{Briefly describe what this study did, including the scope or comparison that readers need. Link the paper here only when its article link is confirmed.}}

## {{First message expressed as an informative subheading}}

  {{A central finding, a plain explanation, and its implication. Preserve the relevant qualification.}}

## {{Second message expressed as an informative subheading}}

  {{The next idea, illustrated with a supported example when helpful.}}

## {{A limitation or enabling condition, when central to the story}}

  {{Explain what the evidence can and cannot tell us without turning this into a full limitations catalogue.}}

## {{The broader takeaway or supported next step}}

  {{Connect the argument and its practical or conceptual significance. Do not repeat every result or overstate the conclusion.}}

  {{A brief link to the original paper, or a clearly identified pending-link note for an editorial draft only.}}
