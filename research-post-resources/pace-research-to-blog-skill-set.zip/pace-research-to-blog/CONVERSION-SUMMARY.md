# How we converted the manuscript into English and Chinese blog posts

## The central editorial decision

We did not translate the whole paper into simpler language or compress each manuscript section. We selected a small number of important, well-supported messages and built a reader-facing explanation around them. The aim was to explain what the study contributes, why it matters, and why someone might read the original research.

The final reference files are [the English post](examples/avian-influenza/post-avian-influenza-models.en.md), [the Chinese post](examples/avian-influenza/post-avian-influenza-models.zh.md), and [the English Word submission](examples/avian-influenza/avian-influenza-models-blog-submission.en.docx). The earlier drafts are not the baseline for future work.

## What we extracted from the research

The English manuscript supplied the science, study scope, findings, caveats, and original figures. The Chinese abstract supplied a terminology reference. The author's comments determined which supported messages deserved the most attention.

We retained the review's scope of 182 studies published through December 2025 and clarified that it concerned avian influenza viruses broadly, not only highly pathogenic viruses. We did not reproduce every model category, subgroup count, data type, or recommendation.

Three messages became central. Machine learning and especially decision-making models were uncommon, which opened a discussion of how models can inform practical choices. Transmission was presented as a process involving interacting host species and communities under climate and land-use change. The conclusion emphasized connecting relevant spatial and temporal scales and biological levels through integrated models or coordinated modules.

Data quality remained a supporting theme because biased observations and unsupported assumptions constrain those aims. The post retained important boundaries. Less-used methods are not automatically better, associations are not established mechanisms, and additional complexity is useful only when the evidence supports it.

## How we organized the language

We used a short question title and an inviting opening summary rather than a labeled abstract. The final English title is “How can we improve models of avian influenza transmission?” Its 49-word opening introduces the wider question and the principal messages. Two brief context paragraphs then explain why models are useful and what the review examined.

Four conceptual sections organize the body. They discuss complementary tools, community processes, data quality, and connections across scales and levels. They do not mirror the manuscript's Introduction, Methods, Results, and Discussion. Each section moves from a finding to an explanation and then to its implication or boundary condition.

Concrete examples do much of the explanatory work. A wetland shared by several species illustrates community composition. A reported-infection map illustrates observation bias. Individual movements connected to seasonal migration illustrate the cross-scale perspective. These examples clarify supported reasoning rather than adding new results.

The language is scientific and approachable without becoming promotional. We removed unnecessary jargon, repeated results, and long enumerations. We corrected grammar while retaining the author's emphasis. Colons and parenthetical dashes were avoided in the main prose. Hyphens in compound words and punctuation inside exact publication titles or URLs were retained.

## Length and reading burden

Using visible-text counts that exclude Markdown syntax, image alt text, and URL strings, the final English version has 1,121 words including its title, headings, captions, and study note. Its opening and main prose contain 955 words across 17 paragraphs. The two captions contribute 107 words. This sits within the 750 to 1,500 word guidance supplied for Methods Blog.

The Chinese version has 2,051 Han characters in its visible text, including headings, captions, and the study note. That count excludes punctuation, Latin letters, and Arabic digits. It is not an English-word equivalent. The purpose of the translation was comparable meaning and accessibility, not an identical numerical length.

For future posts, roughly 900 to 1,200 English words is a useful working target, not a new journal rule. Extra explanation should usually replace less important detail rather than extend the article indefinitely.

## How we used the figures

The figure selection changed as the narrative became more focused. We initially considered manuscript Figures 2, 4, and 5. The model-data heatmap was replaced by the simpler model-frequency panel because the main point was uneven use of modeling approaches. The limitations-and-recommendations figure was subsequently removed because its message could be explained without another dense graphic.

The final Figure 1 comes from manuscript Figure 1A and supports the comparison of modeling approaches. The final Figure 2 comes from manuscript Figure 4 and supports the discussion of recurring research designs and limited coverage across scales and levels. They are numbered according to their order in the blog, not their numbers in the paper.

Both captions help readers interpret the visual. Figure 1 explains that an article can belong to several model groups. Figure 2 explains the reading direction and band widths and explicitly distinguishes combinations of research designs from routes of virus transmission. Both languages use the same original assets, with corresponding captions and alt text.

The governing principle is that a figure must perform a specific explanatory job. An original manuscript figure is not automatically suitable for a public blog, and fewer well-chosen figures can communicate more clearly than a larger collection.

## How we produced the Chinese version

We first corrected and stabilized the English draft. We then translated the meaning into natural Simplified Chinese using the supplied Chinese abstract as a terminology guide. The Chinese version preserves the same argument, examples, qualifications, four thematic sections, four contextual hyperlinks, and two figures.

We did not copy English sentence structure mechanically. Sentence length and ordering could change, but evidence strength could not. Terms such as population, community, biological level, spatial scale, infection, and transmission remained distinct. Neither language adds a stronger claim or an extra recommendation.

## How the final version fits Methods Blog

The relevant benchmark is the journal guidance supplied in this conversation, not an independently checked current policy. The final post uses a descriptive question title, a short introductory summary, meaningful subheadings, simple explanations, a clear account of significance, a suitable length, and a few useful images. Four contextual hyperlinks replace repeated numbered citations and a formal reference list.

Interview framing, anecdotes, co-author quotations, infographics, and multimedia were treated as options rather than a checklist. None were invented or added merely to imitate an informal blog.

English-first drafting, a corresponding Chinese version, avoidance of colons and long dashes, first-line indentation, and compact spacing are PACE preferences. They should not be described as journal requirements. The editor's separate prohibition on AI-generated cover images applies to the cover submission and must not be evaded or silently generalized into an unverified policy for every blog image.

## The final files and the release boundary

The final Markdown files contain ordinary Markdown without HTML or CSS. This avoids the earlier problem in which styling code appeared in the reader. Markdown indentation remains dependent on the renderer. The Word copy uses actual first-line paragraph indents, compact spacing, embedded figures, and clickable hyperlinks.

The English Word document renders to three pages. Its body text matches the English Markdown under the stated counting method. The three-page length is a result of this layout, not a journal limit. The bilingual files have matching figure assets and linked research destinations.

The accepted article's public link is still pending. The draft is formatted for the editorial office, but the related-study note must be updated with the confirmed article link before public release. A dataset DOI must not be used in place of the research-article DOI.

## The reusable skill

[SKILL.md](SKILL.md) converts these decisions into a repeatable workflow. It covers evidence selection, story structure, language rules, length, figure choice and numbering, hyperlinks, Chinese adaptation, file packaging, and final checks. Supporting files include the supplied journal-guidance summary, a worked example, terminology notes, article scaffolds, and a release checklist.

The package retains the final bilingual posts, both figures, and the English Word submission as reference outputs. An offline Python checker tests visible length, figure numbering, local image paths, residual styling or numbered citations, bilingual link and asset consistency, English Word text parity, and pending publication details. These checks assist but do not replace scientific, linguistic, permissions, or visual review.

For future use, provide the skill with the manuscript, figures, author comments, and destination-specific instructions. The completed package is a portable set of instructions and examples. It is not automatically installed in an application or saved as project memory.
