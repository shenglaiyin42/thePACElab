#!/usr/bin/env python3
"""Offline checks for the simple bilingual Markdown and DOCX format used by PACE.

Uses only the Python standard library. This is not a full CommonMark parser.
Checks cannot establish scientific accuracy, translation quality, image rights,
live URL availability, or visual layout. Complete human review as well.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import re
import sys
from typing import Any
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET
import zipfile

LINK = re.compile(r"\[([^\]\n]+)\]\(([^\s)]+)\)")
IMAGE = re.compile(r"!\[([^\]\n]*)\]\(([^\s)]+)\)")
CAPTION = re.compile(r"^\*\*(?:Figure\s*|图\s*)(\d+)([A-Za-z]?)[.．。]")
FIGURE_REF = re.compile(r"(?:\bFigure\s+|图\s*)(\d+)([A-Za-z]?)")
HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
PENDING = re.compile(
    r"(?:article\s+)?link\s+(?:will\s+be\s+added|to\s+be\s+added)|"
    r"not\s+yet\s+(?:published\s+)?online|待补充|链接将在|尚未在线|\{\{|\[\[",
    re.IGNORECASE,
)
NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}


def normalize(text: str) -> str:
    return " ".join(text.split())


def inline_text(text: str) -> str:
    text = LINK.sub(lambda m: m.group(1), text)
    text = re.sub(r"^#{1,6}\s+", "", text)
    return text.replace("**", "").replace("*", "").replace("`", "").strip()


def is_study_note(text: str) -> bool:
    return bool(re.match(
        r"\*?(?:Related study\b|Read the full study\b|相关论文|阅读原文)",
        text.lstrip(), re.IGNORECASE,
    ))


def add_issue(items: list[dict[str, str]], severity: str, message: str) -> None:
    items.append({"severity": severity, "message": message})


def analyze_markdown(path: Path, language: str, release: bool) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8-sig")
    blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
    images = IMAGE.findall(text)
    reading_blocks = [b for b in blocks if not b.startswith(("![", "[!["))]
    captions = [b for b in reading_blocks if CAPTION.match(b)]
    headings = [b for b in reading_blocks if re.match(r"^#{1,6}\s", b)]
    body = [b for b in reading_blocks if b not in captions and b not in headings
            and not is_study_note(b)]
    visible = "\n".join(inline_text(b) for b in reading_blocks)
    body_text = "\n".join(inline_text(b) for b in body)
    research_links = [target for b in reading_blocks for _, target in LINK.findall(b)
                      if urlsplit(target).scheme in ("https", "http")]
    caption_ids = [int(CAPTION.match(b).group(1)) for b in captions]
    ref_ids = [int(m.group(1)) for b in body for m in FIGURE_REF.finditer(inline_text(b))]
    issues: list[dict[str, str]] = []

    if len([h for h in headings if h.startswith("# ")]) != 1:
        add_issue(issues, "error", "Use exactly one level-one article title.")
    if re.search(r"<\s*/?\s*(?:style|script|div|p|html|body)\b|<!--", text, re.I):
        add_issue(issues, "error", "Embedded HTML/CSS or an HTML comment remains.")
    if "```" in text or re.search(r"^ {4}\S", text, re.M):
        add_issue(issues, "warning", "Possible code block or four-space paragraph indent.")
    if re.search(r"\[\d+(?:[,\-–]\d+)*\](?!\()", text):
        add_issue(issues, "warning", "Numbered citation marker remains. Review blog hyperlink style.")
    if re.search(r"[:：]", body_text):
        add_issue(issues, "warning", "Colon in main prose. Review against the author's preference.")
    if "—" in body_text:
        add_issue(issues, "warning", "Em dash in main prose. Prefer commas, sentences, or a necessary short dash.")
    if PENDING.search(text):
        add_issue(issues, "error" if release else "warning",
                  "Publication link or editorial placeholder remains. Resolve before public release.")
    if body and re.match(r"(?:\*\*)?(?:Abstract[.:]|摘要[：:])", body[0], re.I):
        add_issue(issues, "warning", "Opening summary still carries a formal Abstract label.")
    if caption_ids != list(range(1, len(captions) + 1)):
        add_issue(issues, "error", "Caption numbers must be unique and sequential from 1.")
    if len(images) != len(captions):
        add_issue(issues, "warning", "Image and numbered-caption counts differ. Check any unnumbered photo.")
    if any(CAPTION.match(b).group(2) for b in captions):
        add_issue(issues, "warning", "Panel suffix in a blog caption. Check standalone renumbering.")
    if set(ref_ids) - set(caption_ids):
        add_issue(issues, "error", "A text callout has no matching figure caption.")
    if set(caption_ids) - set(ref_ids):
        add_issue(issues, "warning", "A figure is not discussed through a numbered text callout.")

    for index, (alt, target) in enumerate(images, 1):
        parsed = urlsplit(target)
        if not alt.strip():
            add_issue(issues, "warning", f"Image {index} lacks alt text.")
        if parsed.scheme in ("https", "http"):
            add_issue(issues, "warning", f"Image {index} is remote. Its availability and rights are unverified.")
        elif parsed.scheme or Path(unquote(parsed.path)).is_absolute():
            add_issue(issues, "error", f"Image {index} uses a nonportable path.")
        elif not (path.parent / unquote(parsed.path)).is_file():
            add_issue(issues, "error", f"Image {index} cannot be found at {target}.")
        elif Path(parsed.path).name != f"figure-{index}.png":
            add_issue(issues, "info", f"Image {index} has a custom filename. Confirm the source-to-blog mapping.")

    total_words = len(visible.split()) if language == "en" else None
    if language == "en" and total_words is not None and not 750 <= total_words <= 1500:
        add_issue(issues, "warning", "Length falls outside the supplied Methods Blog suggestion of 750 to 1,500 words.")
    if language == "en" and any(len(inline_text(b).split()) > 100 for b in body):
        add_issue(issues, "warning", "A prose paragraph exceeds 100 words. Review readability, not just length.")

    return {
        "file": path.name,
        "language": language,
        "title": inline_text(headings[0]) if headings else "",
        "visible_english_words": total_words,
        "body_english_words": len(body_text.split()) if language == "en" else None,
        "lead_english_words": len(inline_text(body[0]).split()) if body and language == "en" else None,
        "caption_english_words": sum(len(inline_text(b).split()) for b in captions) if language == "en" else None,
        "visible_han_characters": len(HAN.findall(visible)) if language == "zh" else None,
        "body_han_characters": len(HAN.findall(body_text)) if language == "zh" else None,
        "body_paragraphs": len(body),
        "section_headings": len([h for h in headings if h.startswith("## ")]),
        "figure_numbers": caption_ids,
        "image_targets": [target for _, target in images],
        "contextual_hyperlinks": research_links,
        "issues": issues,
        "_visible_text": visible,
    }


def check_docx(path: Path, english: dict[str, Any]) -> dict[str, Any]:
    issues: list[dict[str, str]] = []
    with zipfile.ZipFile(path) as z:
        document = ET.fromstring(z.read("word/document.xml"))
        body = document.find("w:body", NS)
        if body is None:
            raise ValueError("Word document has no body.")
        paragraphs = ["".join(t.text or "" for t in p.findall(".//w:t", NS))
                      for p in body.findall("w:p", NS)]
        docx_text = "\n".join(p for p in paragraphs if p.strip())
        if normalize(docx_text) != normalize(english["_visible_text"]):
            add_issue(issues, "error", "Word body text differs from English Markdown. Review the export.")
        rels = ET.fromstring(z.read("word/_rels/document.xml.rels"))
        targets = {r.get("Id"): r.get("Target", "") for r in rels
                   if r.get("Type", "").endswith("/hyperlink")}
        docx_links = [targets.get(h.get(f"{{{NS['r']}}}id"), "")
                      for h in body.findall(".//w:hyperlink", NS)]
        docx_links = [link for link in docx_links if link.startswith(("http://", "https://"))]
        if Counter(docx_links) != Counter(english["contextual_hyperlinks"]):
            add_issue(issues, "error", "Word and English Markdown hyperlink destinations differ.")
        image_count = len(body.findall(".//w:drawing", NS))
        if image_count != len(english["image_targets"]):
            add_issue(issues, "warning", "Word and Markdown image counts differ.")
        if body.findall(".//w:ins", NS) or body.findall(".//w:del", NS):
            add_issue(issues, "error", "Tracked insertions or deletions remain in Word.")
        if "word/comments.xml" in z.namelist():
            comments = ET.fromstring(z.read("word/comments.xml"))
            if comments.findall("w:comment", NS):
                add_issue(issues, "warning", "Editorial comments remain in Word.")
        if body.findall(".//w:tbl", NS):
            add_issue(issues, "warning", "Tables require separate text and visual review with this checker.")
    return {
        "file": path.name,
        "visible_english_words": len(docx_text.split()),
        "embedded_images": image_count,
        "hyperlink_count": len(docx_links),
        "issues": issues,
        "visual_review_required": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--en", required=True, type=Path, help="Corrected English Markdown")
    parser.add_argument("--zh", type=Path, help="Corresponding Chinese Markdown")
    parser.add_argument("--docx", type=Path, help="English Word submission")
    parser.add_argument("--release", action="store_true", help="Treat pending publication details as errors")
    parser.add_argument("--json", type=Path, help="Also save a JSON report")
    args = parser.parse_args()
    try:
        en = analyze_markdown(args.en, "en", args.release)
        outputs = [en]
        parity: list[dict[str, str]] = []
        if args.zh:
            zh = analyze_markdown(args.zh, "zh", args.release)
            outputs.append(zh)
            for key, label in [("figure_numbers", "figure numbering"),
                               ("image_targets", "image assets"),
                               ("contextual_hyperlinks", "hyperlink targets")]:
                if en[key] != zh[key]:
                    add_issue(parity, "error", f"English and Chinese {label} differ.")
            if en["section_headings"] != zh["section_headings"]:
                add_issue(parity, "warning", "Section counts differ. Check bilingual completeness.")
        if args.docx:
            outputs.append(check_docx(args.docx, en))
        for output in outputs:
            output.pop("_visible_text", None)
        all_issues = [issue for output in outputs for issue in output["issues"]] + parity
        report = {
            "mode": "public_release" if args.release else "editorial_draft",
            "counting_method": "Visible English whitespace-separated words; Chinese Han characters. Includes headings, captions, and study note; excludes markup, image alt text, and URL strings.",
            "files": outputs,
            "bilingual_issues": parity,
            "error_count": sum(i["severity"] == "error" for i in all_issues),
            "warning_count": sum(i["severity"] == "warning" for i in all_issues),
            "limitations": "Offline format checks only. Human factual, translation, permissions, live-link, and rendered-layout review remain necessary.",
        }
        encoded = json.dumps(report, ensure_ascii=False, indent=2)
        print(encoded)
        if args.json:
            args.json.parent.mkdir(parents=True, exist_ok=True)
            args.json.write_text(encoded + "\n", encoding="utf-8")
        return 1 if report["error_count"] else 0
    except (OSError, UnicodeError, ValueError, KeyError, zipfile.BadZipFile, ET.ParseError) as exc:
        print(f"Check failed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
