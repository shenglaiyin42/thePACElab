# Methods in Ecology and Evolution blog guidance

## Status and source

This is a working summary of the Methods Blog guidance supplied by the author in this conversation. It is not an independently verified current journal policy. Check the editor's latest instructions before a future submission, especially for length, links, image rights, and required metadata. Do not turn suggestions into mandatory rules.

The author supplied the [Methods Blog writing and discoverability resource](https://methodsblog.wordpress.com/2015/12/18/seo/) and the complete numbered tips in the conversation. The workflow below is grounded in those supplied tips. Following the linked resource in a future task is optional unless verification or current instructions are needed.

## Guidance relevant to the written post

The blog encourages authors to explain why their work is interesting and how it fits existing knowledge, using simpler language than a research article. A short, descriptive, engaging title and an inviting opening should help non-specialists enter the subject. A question is sufficient. A humorous anecdote or fun fact is not required.

Use sections, informative subheadings, clear explanations, and short paragraphs and sentences. Explain why the work matters. Return naturally to important terms and messages, without repeating entire arguments. Link related content rather than supplying a conventional reference list.

The supplied target is 750 to 1,500 words, with flexibility when more space is justified. A few appropriate pictures are encouraged. An infographic is an option, not an obligation. Image permission and credit still require checking, including for images obtained from Wikimedia Commons.

Interviews, genuine co-author quotations, personal anecdotes, photographs, video, and podcasts are optional formats or additions. Do not fabricate them or add them when they would dilute the article. The supplied podcast recommendation is a maximum of three minutes with a brief caption. It does not set the length of written posts or videos.

## How the PACE version implements the guidance

The final example uses a descriptive question title, a 49-word opening summary without an “Abstract” label, four thematic subheadings, short explanatory paragraphs, two manuscript-derived figures, and four contextual hyperlinks. It explains implications for understanding, surveillance, and management without claiming that the review validated a new model.

Its full English reading text has 1,121 words, including the title, headings, captions, and related-study note. The two images are placed where they support the narrative. The final article avoids a formal reference list, invented quotations, and compulsory interview framing.

## What belongs to PACE rather than the journal

English-first drafting followed by an equivalent Simplified Chinese version is a PACE workflow. So are first-line paragraph indentation, compact Word spacing, avoidance of colons and parenthetical dashes, clean Markdown without embedded CSS, and explicit download links for files. The supplied journal guidance does not prescribe these choices.

A working target of roughly 900 to 1,200 English words, a 40 to 65 word lead, and one or two primary figures are useful lab defaults derived from this editing experience. They are not fixed journal limits. The example's three-page Word layout is not a page requirement.

The separate editorial message excluding AI-generated cover images should be honored for the cover. It should not be silently recast as a complete policy governing every possible blog image. Check any additional image restrictions with the relevant instructions.

## Submission and release

The example is formatted for sending to the editorial office, but the article DOI or URL remains pending. Final public release requires the confirmed article link, any requested author information, image credits or permissions, and removal of editorial placeholders. Do not infer the research article's DOI from a related dataset DOI.
