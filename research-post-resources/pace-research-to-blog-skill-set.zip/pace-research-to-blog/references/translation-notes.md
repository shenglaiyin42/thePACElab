# Bilingual writing and terminology

## Transfer the argument, not the sentence shape

Translate from the latest corrected English. Preserve the scientific claim, evidence, uncertainty, examples, and practical meaning. Use the author's Chinese abstract to select terminology. Allow sentence splitting and reordering so Chinese readers do not have to decode English syntax.

A term's everyday explanation may replace jargon in both languages, but it must preserve the distinction that matters. In the worked example, “studies that look ahead” became “面向未来的研究.” An explanation of species sharing a wetland remained an illustrative question, not a newly reported experiment.

The phrase “how long viruses remain infectious in the environment” became “病毒在环境中保持感染性的时间.” This is more explicit for beginners than an unexplained technical label, and does not imply that every viral detection represents infectious virus.

## Case-study terminology

These are examples from the avian influenza project, not a compulsory vocabulary for unrelated subjects.

| English concept | Preferred Chinese expression in context |
| --- | --- |
| statistical models | 统计模型 |
| mechanistic models | 机制模型 |
| machine learning | 机器学习 |
| decision-making models | 决策模型 |
| decision analysis | 决策分析 |
| host | 宿主 |
| host interactions | 宿主之间的相互作用 |
| population and multi-population | 种群与多种群 |
| community composition | 群落组成 |
| individual-based model | 基于个体的模型 |
| agent-based model | 基于主体的模型 |
| biological levels | 生物组织层次 |
| spatial and temporal scales | 空间尺度和时间尺度，或时空尺度 |
| cross-scale and cross-level | 跨尺度、跨层次 |
| integrated model | 整合模型 |
| linked model modules | 相互衔接的模型模块 |
| retrospective studies | 回溯性研究，或分析过去事件的研究 |
| prospective studies | 前瞻性研究，或面向未来的研究 |
| surveillance and imperfect detection | 监测与漏检，按句意解释 |
| land-use change | 土地利用变化 |

Do not collapse population and community, infection and transmission, or biological level and spatial scale. Do not equate statistical association with a demonstrated mechanism. Do not force identical English and Chinese word counts.

## Two-language check

Read corresponding sections side by side. Confirm that numbers, dates, species, units, evidence sources, uncertainty, examples, figure order, captions, and linked destinations agree. Translate image alt text. A translated figure title must not change what the figure actually represents.

Use the same evidence strength in each language. An opportunity to improve modeling is not a guarantee of better predictions. The possibility that species interactions influence spread must not become an assertion that every mixed-species community increases risk.

Keep Chinese prose direct. Avoid inflated expressions such as claims of revolutionary significance, excessive academic nominalizations, unnecessary four-character slogans, and repeated “本研究” constructions. Use natural Chinese punctuation while respecting the author's preference to avoid colons and long parenthetical dashes.

Preserve ordinary punctuation inside exact English publication titles and URLs. The original title in the final related-study note contains a colon. That is an accurate title, not an exception that licenses colon-heavy article prose.
