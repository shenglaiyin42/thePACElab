# From an avian influenza review to two blog posts

## Authoritative final files

The retained English example is titled “How can we improve models of avian influenza transmission?” The Chinese title is “如何改进禽流感传播模型？” These are the last generated submission files, not the earlier drafts or their original titles.

Read the [final English Markdown](../examples/avian-influenza/post-avian-influenza-models.en.md), [final Chinese Markdown](../examples/avian-influenza/post-avian-influenza-models.zh.md), and [English Word submission](../examples/avian-influenza/avian-influenza-models-blog-submission.en.docx). They are copied without rewriting. The manuscript is not reproduced in this skill package. The articles still contain an explicitly pending paper link and should not be represented as already published.

## What we retained and what we removed

The source was an accepted systematic review of 182 avian influenza transmission-modeling studies published through December 2025. The supplied manuscript and figures were the factual basis. The Chinese abstract supplied terminology. The post preserved the review's broad avian influenza scope rather than presenting it as exclusively about highly pathogenic viruses.

Early versions carried too many category counts and closely resembled a shortened paper. The author clarified that the post should briefly introduce what was done, emphasize a few major discussions and recommendations, and encourage readers to consult the original research. We therefore retained the study's scale and a few broad patterns, rather than reciting every results subsection.

Three author-selected messages became the center of the story. First, machine learning and especially decision-making models were uncommon, and practical management choices deserved greater attention. Second, transmission should be understood through interacting host species and communities under climate and land-use change. Third, relevant spatial and temporal scales and biological levels may need to be connected through one integrated model or through coordinated modules.

Data quality remained as a supporting section because it constrains those aims. The post retained the warning that surveillance records reflect where people looked and what was detected, not simply where transmission occurred.

## How we organized the language

The final opening asks what models can help us understand and decide. It states the review's size and three priorities without adopting an abstract's formal structure. Two brief context paragraphs explain why models are useful and what the review examined.

Four subheadings then organize the story around different tools, community processes, better data, and connections across scales and levels. Findings lead into explanations and implications. The ending returns to understanding, anticipating change, and choosing actions rather than maximizing complexity.

Technical ideas are explained through familiar situations. A shared wetland illustrates community composition. An infection-report map illustrates surveillance bias. A host's daily movements linked with seasonal migration illustrates the cross-scale argument. These examples explain the manuscript's reasoning without inventing new empirical results.

The final text repairs grammar, including the comma splice in the edited sentence about less-used methods, while retaining the author's argument. It removes repeated numbered citations in favor of four contextual hyperlinks. There is no formal bibliography, fabricated interview, invented anecdote, or standalone social-media blurb.

The final English and Chinese main prose contain no colons or parenthetical dashes. Hyphens in terms such as “decision-making” remain. The exact original research title retains its colon in the closing publication note.

## Measured length

Counts use visible text, exclude Markdown syntax, image alt text, and URL strings, and treat English whitespace-separated tokens as words. This method matches the extracted main-body Word text for the English example. Other word processors may count compounds slightly differently.

| Measure | Final example |
| --- | --- |
| English total, including title, headings, captions, and study note | 1,121 words |
| English opening and main prose, excluding headings, captions, and study note | 955 words |
| Opening summary | 49 words |
| English figure captions | 107 words combined |
| Main-prose paragraphs, including opening | 17 |
| Main-prose paragraph range | 22 to 82 words |
| Thematic subheadings | 4 |
| Chinese visible Han characters, including headings, captions, and study note | 2,051 |
| Chinese main-prose Han characters | 1,783 |
| Retained figures | 2 |
| Contextual research hyperlinks | 4 in each language |
| Rendered English Word length | 3 pages |

Chinese character counts exclude punctuation, Latin letters, and Arabic digits. They are not English-word equivalents. These are descriptive measurements, not rigid targets.

## How the figure selection changed

The initial selection used manuscript Figures 2, 4, and 5. Once the author emphasized methods and actionable decisions, the detailed model-data heatmap was less direct than a simple comparison of modeling approaches. We replaced it with panel A of manuscript Figure 1.

The limitations-and-recommendations figure was later removed for the Methods Blog adaptation. Its message was already conveyed by the surveillance example, and retaining it would have increased visual density without advancing the three main messages.

The final mapping is recorded below. Public numbering follows the post, not the source paper.

| Blog asset | Original source | Narrative role |
| --- | --- | --- |
| Figure 1, `figures/figure-1.png` | Manuscript Figure 1A | Show uneven use of modeling approaches alongside the methods discussion |
| Figure 2, `figures/figure-2.png` | Manuscript Figure 4 | Show recurring combinations of research methods, data, hosts, scales, levels, and objectives near the cross-scale discussion |

The first caption explains that articles may appear in more than one category and defines ML and DM. The second explains reading direction and band width, acknowledges multiple combinations per article, and states that the ribbons represent research designs, not transmission routes or a proposed integrated model.

The Chinese post uses the same images and numbers, with translated captions and alt text. No new photograph was added to the final version. The earlier AI-generated infographic is not included and must not replace the original quantitative figures. Its displayed counts were inconsistent with the manuscript, so it is not a factual visual source.

## Bilingual conversion

We first corrected and stabilized the English narrative. The Chinese version then followed that corrected text rather than an older draft. It retained the same four sections, examples, four hyperlinks, two figure references, and scientific qualifications. Natural Chinese sentence structure took priority over word-for-word equivalence.

For example, the conclusion preserves the distinction between integrating relevant processes and adding unsupported complexity. Neither language claims that every research question needs a cross-scale model or that a less-used approach is inherently superior.

## File and layout decisions

An earlier attempt to enforce spacing with embedded HTML and CSS displayed code in the author's Markdown reader. We removed those blocks. The final Markdown contains only ordinary headings, prose, image links, hyperlinks, and captions. Unicode spaces provide a first-line cue, but precise layout depends on the renderer.

The Word copy implements the requested layout with paragraph styles rather than code or empty paragraphs. Inspection of the retained file gives the following baseline. Body text uses 11.5-point Calibri, line spacing of about 1.12, no space before or after, and a first-line indent of about 0.32 inches. The title is 20 points. Section headings are 13 points with seven points before and two after. Captions are 10 points with three points before and four after. These are practical formatting choices, not journal-mandated settings.

The final Word file contains two embedded figures and four clickable hyperlinks. Its extracted body text matches the English Markdown under the stated counting method. All three rendered pages were inspected when preparing this skill. These documents are examples, not templates that require identical pagination or a particular font.

## Alignment with the supplied journal guidance

The final post fits the supplied 750 to 1,500 word recommendation, uses a question title and short introduction, has thematic subheadings, explains why the work matters, and uses contextual hyperlinks rather than a reference list. It keeps a few useful visuals rather than trying to reproduce every figure. Interviews, quotations, multimedia, and anecdotes were treated as optional.

The one remaining release task is to replace the accepted-paper note with the confirmed research-article link. It is therefore a formatted editorial submission with a known pending publication detail, not an unconditionally publication-ready web page.

## General lesson

Select and explain, rather than compress and inventory. A blog should preserve the important science while changing the reading experience. The transferable method is to identify a small set of supported messages, organize them around questions readers can follow, use figures to answer specific narrative needs, translate meaning faithfully, and verify the actual files delivered.
